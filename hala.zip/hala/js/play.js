playGame = {
	create:function() {
		
			game.add.sprite(0,0, 'bg');
			


			

		    bgmusic = game.add.audio("bgmusic");
			bgmusic.play('',0,1,true);


			
			flag = game.add.group();
			flag.enableBody = true;

			var coin = flag.create(3920,275,'coinss');

			plats = game.add.group();
			plats.enableBody = true;
		
			var coin = plats.create(415,270,'coin');
			var coin = plats.create(445,270,'coin');
			var coin = plats.create(475,270,'coin');
			var coin = plats.create(520,350,'coins');
			var coin = plats.create(520,400,'coins');
			var coin = plats.create(520,450,'coins');
			var coin = plats.create(570,510,'coin');
			var coin = plats.create(610,510,'coin');
			var coin = plats.create(650,510,'coin');
			var coin = plats.create(690,450,'coins');
			var coin = plats.create(690,400,'coins');
			var coin = plats.create(690,200,'coin');
			var coin = plats.create(850,200,'coin');
			var coin = plats.create(880,200,'coin');
			var coin = plats.create(910,200,'coin');
			var coin = plats.create(940,200,'coin');
			var coin = plats.create(970,200,'coin');
			var coin = plats.create(1000,200,'coin');
			var coin = plats.create(1030,200,'coin');
			var coin = plats.create(1060,200,'coin');
			var coin = plats.create(1090,200,'coin');
			var coin = plats.create(1120,200,'coin');
			var coin = plats.create(1150,200,'coin');
			var coin = plats.create(1310,330,'coins');
			var coin = plats.create(1490,330,'coins');
			var coin = plats.create(1400,200,'coin');
			var coin = plats.create(1670,370,'coin'); 
			var coin = plats.create(1710,370,'coin');
			var coin = plats.create(1750,370,'coin');
			var coin = plats.create(1790,370,'coin');  
			var coin = plats.create(1910,165,'coin'); //
			var coin = plats.create(1960,165,'coin');  
			var coin = plats.create(2010,165,'coin'); 
			var coin = plats.create(2060,165,'coin'); 
			var coin = plats.create(2110,165,'coin'); 
			var coin = plats.create(2160,165,'coin');  
			var coin = plats.create(2210,165,'coin'); 
			var coin = plats.create(2250,165,'coin');
			var coin = plats.create(1910,510,'coin'); // 
			var coin = plats.create(1960,510,'coin');   
			var coin = plats.create(2010,510,'coin'); 
			var coin = plats.create(2060,510,'coin');  
			var coin = plats.create(2110,510,'coin');  
			var coin = plats.create(2160,510,'coin'); 
			var coin = plats.create(2210,510,'coin');  
			var coin = plats.create(2250,510,'coin');
			var coin = plats.create(2270,270,'coins');
			var coin = plats.create(2270,310,'coins');
			var coin = plats.create(2270,350,'coins');
			var coin = plats.create(2270,390,'coins');
			var coin = plats.create(2270,430,'coins');
			var coin = plats.create(2270,470,'coins');
			var coin = plats.create(2310,510,'coin'); //
			var coin = plats.create(2360,510,'coin');
			var coin = plats.create(2410,510,'coin');
			var coin = plats.create(2460,510,'coin');
			var coin = plats.create(2500,510,'coin');
			var coin = plats.create(2310,165,'coin'); //
			var coin = plats.create(2360,165,'coin');
			var coin = plats.create(2410,165,'coin');
			var coin = plats.create(2460,165,'coin');
			var coin = plats.create(2500,165,'coin');
			var coin = plats.create(2590,370,'coin');//
			var coin = plats.create(2640,370,'coin');
			var coin = plats.create(2690,370,'coin');

			var coin = plats.create(2800,185,'coin');
			var coin = plats.create(2850,185,'coin');
			var coin = plats.create(2900,185,'coin');
			var coin = plats.create(2950,185,'coin');
			var coin = plats.create(3000,185,'coin');
			var coin = plats.create(3050,185,'coin');
			var coin = plats.create(3100,185,'coin');
			var coin = plats.create(3150,185,'coin');
			var coin = plats.create(3200,185,'coin');
			var coin = plats.create(3250,185,'coin');
			var coin = plats.create(3300,185,'coin');
			var coin = plats.create(3350,185,'coin');
			var coin = plats.create(3400,185,'coin');

			var coin = plats.create(3168,240,'coins');
			var coin = plats.create(3168,280,'coins');
			var coin = plats.create(3168,320,'coins');
			//var coin = plats.create(3168,360,'coins');

			var coin = plats.create(3000,375,'coin');
			var coin = plats.create(3050,375,'coin');
			var coin = plats.create(3100,375,'coin');
			var coin = plats.create(3150,375,'coin');
			var coin = plats.create(3200,375,'coin');
			var coin = plats.create(3250,375,'coin');
			var coin = plats.create(3300,375,'coin');
			var coin = plats.create(3350,375,'coin');
			var coin = plats.create(3400,375,'coin');

			var coin = plats.create(2800,510,'coin');
			var coin = plats.create(2850,510,'coin');
			var coin = plats.create(2900,510,'coin');
			var coin = plats.create(2950,510,'coin');
			var coin = plats.create(3000,510,'coin');
			var coin = plats.create(3050,510,'coin');
			var coin = plats.create(3100,510,'coin');
			var coin = plats.create(3150,510,'coin');
			var coin = plats.create(3200,510,'coin');
			var coin = plats.create(3250,510,'coin');
			var coin = plats.create(3300,510,'coin');
			var coin = plats.create(3350,510,'coin');
			var coin = plats.create(3400,510,'coin');
			var coin = plats.create(3450,510,'coin');
			var coin = plats.create(3500,510,'coin');
			var coin = plats.create(3550,510,'coin');
			var coin = plats.create(3600,510,'coin');

			var coin = plats.create(3618,185,'coin');
			var coin = plats.create(3668,185,'coin');
			var coin = plats.create(3718,185,'coin');
			var coin = plats.create(3768,185,'coin');
			var coin = plats.create(3818,185,'coin');
			var coin = plats.create(3868,185,'coin');
			var coin = plats.create(3618,230,'coin');
			var coin = plats.create(3668,230,'coin');
			var coin = plats.create(3718,230,'coin');
			var coin = plats.create(3768,230,'coin');
			var coin = plats.create(3818,230,'coin');
			var coin = plats.create(3868,230,'coin');

			platforms = game.add.group();
			platforms.enableBody = true;

	

	
			
			var ground = platforms.create(-90,game.world.height -40,'ground');
			ground.scale.setTo(3.7,1);
			ground.body.immovable = true;

			var ledge = platforms.create(0,-140,'groundss'); // vertical pinaka una
			ledge.body.immovable = true;
			
			var ledge = platforms.create(0,0,'grounded'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3970,0,'grounded'); // vertical pinaka una
			ledge.body.immovable = true;
			



			var ledge = platforms.create(750,420,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(200,420,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(180,150,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(120,150,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(25,150,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(411,370,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(420,510,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(580,140,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(580,140,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(580,275,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(580,310,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1200,420,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1290,390,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1380,350,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1380,380,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1470,390,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1560,420,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1680,150,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1680,420,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1910,350,'groun'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1770,450,'groun'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2450,350,'groun'); // vertical pinaka una
			ledge.body.immovable = true;
			
			var ledge = platforms.create(1630,420,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1920,215,'groundse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2325,215,'groundee'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2590,420,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2590,150,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2800,250,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2950,430,'grou'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3220,430,'grou'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2870,300,'gro'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3240,300,'gro'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2790,370,'plat2'); // vertical pinaka una
			ledge.body.immovable = true;

			var ledge = platforms.create(2710,490,'plat2'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3450,250,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3450,150,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3850,350,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;

			pins = game.add.group();
			pins.enableBody = true;

			var tusok = pins.create(292,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(314,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(336,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(358,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(380,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(841,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(863,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(884,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(902,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(924,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(946,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(968,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(990,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1012,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1036,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1058,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1080,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1102,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1124,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1146,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1168,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1410,305,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1541,343,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1825,513,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(2280,513,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(2565,513,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3423,386,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(2945,386,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3596,386,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3618,386,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3830,513,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;


			var tusok = pins.create(279,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(301,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(323,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(345,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(367,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(389,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(411,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(435,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(458,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(481,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(503,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(525,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(548,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1825,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(2563,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3233,323,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3115,323,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3575,460,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3553,460,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3531,460,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;

			



			button = game.add.button(650,450,"button",this.talon);
		   	button1 = game.add.button(100,450,"button1",this.kanan);
		   	button2 = game.add.button(250,445,"button2",this.kaliwa);
		   	btn = game.add.button(380,10,"pause",this.tigilTuloy);
			
			

			plat = game.add.sprite(860,350,"plat");
			plat.scale.x=1;
			plat.scale.y=1;
			game.physics.arcade.enable(plat);
			plat.body.collideWorldBounds = true;
			plat.body.immovable = true;

			plat2 = game.add.sprite(2273,550,"plat2");
			plat2.scale.x=1;
			plat2.scale.y=1;
			game.physics.arcade.enable(plat2);
			plat2.body.collideWorldBounds = true;
			plat2.body.immovable = true;
			
			player = game.add.sprite(32,game.world.height -150,'dude');
			
			
			game.physics.arcade.enable(player);
			game.physics.arcade.enable(platforms);
			
			player.body.bounce.y = 0.9;
			player.body.gravity.y = 800;
			player.body.collideWorldBounds = true;
			
			player.animations.add('left',[0,1,2,3],10,true);
			player.animations.add('right',[5,6,7,8],10,true);
			player.body.velocity.x =0;
			

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.platMoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.platMoveLeft);
			
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.plat2MoveDown);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.plat2MoveUp);

			
			
			bestScoreText = game.add.text(570,20,"BestScore: "+ playGame.getScore(),{fill:'blue'});
			scoreText = game.add.text(50,20,"SCORE: 0",{fill:'blue'});
			
			stateText = game.add.text(game.world.centerX,game.world.centerY,' ', { font: '30px Arial', fill: 'black' });
		    stateText.anchor.setTo(0.5, 0.5);
			game.scale.refresh();




			
			game.camera.follow(player,Phaser.Camera.FOLLOW_TOPDOWN);
			scoreText.fixedToCamera = true;
			bestScoreText.fixedToCamera = true;
			scoreText.fixedToCamera = true;
			bestScoreText.fixedToCamera = true;
			button.fixedToCamera = true;
			button1.fixedToCamera = true;
			button2.fixedToCamera = true;
			btn.fixedToCamera = true;


			
			
			//titlepage = game.add.sprite(0,0, "title");
			//startButton = game.add.button(game.world.centerX -450, 330, 'btn', proseso.actionOnClick, this, 2, 1, 1);

	},

	update:function() {
			game.physics.arcade.collide(player,platforms,0,0);
			game.physics.arcade.collide(player,plat,0,0);
			game.physics.arcade.collide(player,plat2,0,0);
			game.physics.arcade.overlap(player,pins,this.killPlayer);
			game.physics.arcade.overlap(player,flag,this.killPlayerr);
			game.physics.arcade.overlap(player,plats,this.killcoin);
			
			var x= 0;
		    if(keyboard.left.isDown){
		         x++;
		        player.animations.play('left');
		        player.body.velocity.x = -200;
		        // bg.frame = 0;
		    }
		    else if(keyboard.right.isDown){
		         x++;
		        // bg.frame = 1;
		        player.animations.play('right');
		        player.body.velocity.x = 200;
		    }
		    else{
		        player.body.velocity.x = 0;
		        player.animations.stop();
		    }

		    if(keyboard.up.isDown && player.body.touching.down){
		        player.body.velocity.y = -500;
		    }
				
		
		},
		killcoin:function(player,coin){
            score = score + 1;
            scoreText.text = "SCORE:"+ score;
            coin.kill();
            
        	
            if(playGame.getScore()<=score){
                saveScore(score);
                bestScoreText.text = "bestscore: "+score;
            }
        },

        talon:function(){
            button.frame = 1;
            if(player.body.touching.down){

                player.body.velocity.y = -500;
            }

            setTimeout(function(){
                button.frame = 0;
            },300)
        },


        kanan:function(){
           button1.frame = 1;
            //	if(keyboard.left.isDown){
           		player.body.velocity.x = -2500;
           		player.animations.add('left',[0,1,2,3,4],10,true);
           	//	}
            setTimeout(function(){
            	
            	player.animations.play('left');

                button1.frame = 0;
               },300)
        },


        kaliwa:function(){
            button2.frame = 1;
            //	if(keyboard.right.isDown){
            	player.animations.add('right',[5,6,7,8],10,true);
           		player.body.velocity.x = 2500;
           	//	}
            setTimeout(function(){
        		player.animations.play('right');

                button2.frame = 0;
               },100)
        },
        tigilTuloy:function(){
            setTimeout(function(){
                btn.frame = 1;
                game._paused = false;

            },3000)
            	btn.frame = 0;

            game._paused =true;
        },  	




        getScore:function(){
            return (localStorage.getItem("gameData") == null || localStorage.getItem("gameData") == "")?0:localStorage.getItem("gameData");
        },
        saveScore:function(score){
            localStorage.setItem("gameData",score);
        },

        platMoveRight:function() {
            
        			plat.body.velocity.x = 250;
                    plat.animations.play('right');

        },
        platMoveLeft:function() {
            
        			plat.body.velocity.x = -250;
                    plat.animations.play('left');

        },

        plat2MoveDown:function() {
            
        		plat2.body.velocity.y = -300;
        		plat2.animations.play('down');

        },
        plat2MoveUp  :function() {
            
        		plat2.body.velocity.y =300;
        		plat2.animations.play('up');

        },


        killPlayer:function(player,tusok){
              	player.kill();
                bgmusic.stop();

        	 	 
	        	var pausedText = game.add.text(250, 360, "Tap anywhere to Menu.", { fontSize: '28px', fill: 'red' });

					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            //window.location.href=window.location.href;
					            pausedText.fixedToCamera = true;

					            
							}, this);


        		},

        restart :function(){
            window.location.href=window.location.href;
            stateText.visible = false;
        },

        killPlayerr:function(player,flag){
               gameOverText = game.add.text(w/2-100,h/2,"YOU WIN !!",{fill:'BLUE'});
               gameOverText.fixedToCamera = true;
            bgmusic.stop();
        	   player.animations.stop();
        	   stateText.text="DOUBLE TAP \n    to restart";   
            	game._paused = true; 
               
                player.kill();
        	},

			
}