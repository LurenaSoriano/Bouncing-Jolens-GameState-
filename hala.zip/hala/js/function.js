mambobola.prototype = {
    init:function(){

    },
	preload:function() {

	
			game.load.image('ground','img/horin.png');
			game.load.image('grounded','img/vertical.png');
			game.load.image('grounds','img/plat.png');
			game.load.image('groundss','img/11.png');
			game.load.image('groundsse','img/plat1.png');
			game.load.image('groundse','img/plat2.png');
			game.load.image('groundee','img/plat3.png');
			game.load.image('groun','img/1.png');
			game.load.image('grou','img/hh.png');
			game.load.image('gro','img/ee.png');
			//game.load.image('btn1', 'img/start.png');
			
		   // game.load.image('title','img/harap.png',800,600);
			//game.load.image('startButton', 'img/start.png');
			
			game.load.spritesheet("pause","img/tigil.png",100,100);
			
			game.load.spritesheet("button","img/btn-jump.png",100,100);
			game.load.spritesheet("button1","img/btn-left.png",100,100);
			game.load.spritesheet("button2","img/btn-right.png",100,100);
			game.load.image('tusok','img/pin.png');
			game.load.image('vtusok','img/pin2.png');
			game.load.image('bg','img/bg.png');
			game.load.spritesheet('dude','img/b.png',32,48);
			game.load.image('plat', 'img/moveplat.png');
			game.load.image('plat2','img/2.png');
			game.load.image('coin','img/r.png');
			game.load.image('coins','img/r2.png');
			game.load.image('coinss','img/flag.png');

			game.load.audio("bgmusic","audio/suspense.mp3");


	},

	create:function() {
			game.physics.startSystem(Phaser.Physics.ARCADE);
			game.add.sprite(0,0, 'bg');
			game.world.setBounds(0,0,boundsRight,0);


			game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
		    game.scale.forceLandscape = true;
		    game.scale.pageAlignHorizontally = true;

		    bgmusic = game.add.audio("bgmusic");
			bgmusic.play('',0,1,true);


			
			flag = game.add.group();
			flag.enableBody = true;

			var coin = flag.create(3920,275,'coinss');

			plats = game.add.group();
			plats.enableBody = true;
		
			var coin = plats.create(415,270,'coin');
			var coin = plats.create(445,270,'coin');
			var coin = plats.create(475,270,'coin');
			var coin = plats.create(520,350,'coins');
			var coin = plats.create(520,400,'coins');
			var coin = plats.create(520,450,'coins');
			var coin = plats.create(570,510,'coin');
			var coin = plats.create(610,510,'coin');
			var coin = plats.create(650,510,'coin');
			var coin = plats.create(690,450,'coins');
			var coin = plats.create(690,400,'coins');
			var coin = plats.create(690,200,'coin');
			var coin = plats.create(850,200,'coin');
			var coin = plats.create(880,200,'coin');
			var coin = plats.create(910,200,'coin');
			var coin = plats.create(940,200,'coin');
			var coin = plats.create(970,200,'coin');
			var coin = plats.create(1000,200,'coin');
			var coin = plats.create(1030,200,'coin');
			var coin = plats.create(1060,200,'coin');
			var coin = plats.create(1090,200,'coin');
			var coin = plats.create(1120,200,'coin');
			var coin = plats.create(1150,200,'coin');
			var coin = plats.create(1310,330,'coins');
			var coin = plats.create(1490,330,'coins');
			var coin = plats.create(1400,200,'coin');
			var coin = plats.create(1670,370,'coin'); 
			var coin = plats.create(1710,370,'coin');
			var coin = plats.create(1750,370,'coin');
			var coin = plats.create(1790,370,'coin');  
			var coin = plats.create(1910,165,'coin'); //
			var coin = plats.create(1960,165,'coin');  
			var coin = plats.create(2010,165,'coin'); 
			var coin = plats.create(2060,165,'coin'); 
			var coin = plats.create(2110,165,'coin'); 
			var coin = plats.create(2160,165,'coin');  
			var coin = plats.create(2210,165,'coin'); 
			var coin = plats.create(2250,165,'coin');
			var coin = plats.create(1910,510,'coin'); // 
			var coin = plats.create(1960,510,'coin');   
			var coin = plats.create(2010,510,'coin'); 
			var coin = plats.create(2060,510,'coin');  
			var coin = plats.create(2110,510,'coin');  
			var coin = plats.create(2160,510,'coin'); 
			var coin = plats.create(2210,510,'coin');  
			var coin = plats.create(2250,510,'coin');
			var coin = plats.create(2270,270,'coins');
			var coin = plats.create(2270,310,'coins');
			var coin = plats.create(2270,350,'coins');
			var coin = plats.create(2270,390,'coins');
			var coin = plats.create(2270,430,'coins');
			var coin = plats.create(2270,470,'coins');
			var coin = plats.create(2310,510,'coin'); //
			var coin = plats.create(2360,510,'coin');
			var coin = plats.create(2410,510,'coin');
			var coin = plats.create(2460,510,'coin');
			var coin = plats.create(2500,510,'coin');
			var coin = plats.create(2310,165,'coin'); //
			var coin = plats.create(2360,165,'coin');
			var coin = plats.create(2410,165,'coin');
			var coin = plats.create(2460,165,'coin');
			var coin = plats.create(2500,165,'coin');
			var coin = plats.create(2590,370,'coin');//
			var coin = plats.create(2640,370,'coin');
			var coin = plats.create(2690,370,'coin');

			var coin = plats.create(2800,185,'coin');
			var coin = plats.create(2850,185,'coin');
			var coin = plats.create(2900,185,'coin');
			var coin = plats.create(2950,185,'coin');
			var coin = plats.create(3000,185,'coin');
			var coin = plats.create(3050,185,'coin');
			var coin = plats.create(3100,185,'coin');
			var coin = plats.create(3150,185,'coin');
			var coin = plats.create(3200,185,'coin');
			var coin = plats.create(3250,185,'coin');
			var coin = plats.create(3300,185,'coin');
			var coin = plats.create(3350,185,'coin');
			var coin = plats.create(3400,185,'coin');

			var coin = plats.create(3168,240,'coins');
			var coin = plats.create(3168,280,'coins');
			var coin = plats.create(3168,320,'coins');
			//var coin = plats.create(3168,360,'coins');

			var coin = plats.create(3000,375,'coin');
			var coin = plats.create(3050,375,'coin');
			var coin = plats.create(3100,375,'coin');
			var coin = plats.create(3150,375,'coin');
			var coin = plats.create(3200,375,'coin');
			var coin = plats.create(3250,375,'coin');
			var coin = plats.create(3300,375,'coin');
			var coin = plats.create(3350,375,'coin');
			var coin = plats.create(3400,375,'coin');

			var coin = plats.create(2800,510,'coin');
			var coin = plats.create(2850,510,'coin');
			var coin = plats.create(2900,510,'coin');
			var coin = plats.create(2950,510,'coin');
			var coin = plats.create(3000,510,'coin');
			var coin = plats.create(3050,510,'coin');
			var coin = plats.create(3100,510,'coin');
			var coin = plats.create(3150,510,'coin');
			var coin = plats.create(3200,510,'coin');
			var coin = plats.create(3250,510,'coin');
			var coin = plats.create(3300,510,'coin');
			var coin = plats.create(3350,510,'coin');
			var coin = plats.create(3400,510,'coin');
			var coin = plats.create(3450,510,'coin');
			var coin = plats.create(3500,510,'coin');
			var coin = plats.create(3550,510,'coin');
			var coin = plats.create(3600,510,'coin');

			var coin = plats.create(3618,185,'coin');
			var coin = plats.create(3668,185,'coin');
			var coin = plats.create(3718,185,'coin');
			var coin = plats.create(3768,185,'coin');
			var coin = plats.create(3818,185,'coin');
			var coin = plats.create(3868,185,'coin');
			var coin = plats.create(3618,230,'coin');
			var coin = plats.create(3668,230,'coin');
			var coin = plats.create(3718,230,'coin');
			var coin = plats.create(3768,230,'coin');
			var coin = plats.create(3818,230,'coin');
			var coin = plats.create(3868,230,'coin');

			platforms = game.add.group();
			platforms.enableBody = true;

	

	
			
			var ground = platforms.create(-90,game.world.height -40,'ground');
			ground.scale.setTo(3.7,1);
			ground.body.immovable = true;

			var ledge = platforms.create(0,-140,'groundss'); // vertical pinaka una
			ledge.body.immovable = true;
			
			var ledge = platforms.create(0,0,'grounded'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3970,0,'grounded'); // vertical pinaka una
			ledge.body.immovable = true;
			



			var ledge = platforms.create(750,420,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(200,420,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(180,150,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(120,150,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(25,150,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(411,370,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(420,510,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(580,140,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(580,140,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(580,275,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(580,310,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1200,420,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1290,390,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1380,350,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1380,380,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1470,390,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1560,420,'grounds'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1680,150,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1680,420,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1910,350,'groun'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1770,450,'groun'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2450,350,'groun'); // vertical pinaka una
			ledge.body.immovable = true;
			
			var ledge = platforms.create(1630,420,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(1920,215,'groundse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2325,215,'groundee'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2590,420,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2590,150,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2800,250,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2950,430,'grou'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3220,430,'grou'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2870,300,'gro'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3240,300,'gro'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(2790,370,'plat2'); // vertical pinaka una
			ledge.body.immovable = true;

			var ledge = platforms.create(2710,490,'plat2'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3450,250,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3450,150,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;
			var ledge = platforms.create(3850,350,'groundsse'); // vertical pinaka una
			ledge.body.immovable = true;

			pins = game.add.group();
			pins.enableBody = true;

			var tusok = pins.create(292,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(314,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(336,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(358,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(380,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(841,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(863,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(884,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(902,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(924,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(946,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(968,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(990,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1012,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1036,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1058,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1080,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1102,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1124,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1146,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1168,515,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1410,305,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1541,343,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1825,513,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(2280,513,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(2565,513,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3423,386,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(2945,386,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3596,386,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3618,386,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3830,513,'tusok'); // vertical pinaka una
			tusok.body.immovable = true;


			var tusok = pins.create(279,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(301,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(323,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(345,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(367,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(389,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(411,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(435,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(458,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(481,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(503,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(525,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(548,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(1825,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(2563,157,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3233,323,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3115,323,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3575,460,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3553,460,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;
			var tusok = pins.create(3531,460,'vtusok'); // vertical pinaka una
			tusok.body.immovable = true;

			



			button = game.add.button(650,450,"button",proseso.talon);
		   	button1 = game.add.button(100,450,"button1",proseso.kanan);
		   	button2 = game.add.button(250,445,"button2",proseso.kaliwa);
		   	btn = game.add.button(380,10,"pause",proseso.tigilTuloy);
			
			

			plat = game.add.sprite(860,350,"plat");
			plat.scale.x=1;
			plat.scale.y=1;
			game.physics.arcade.enable(plat);
			plat.body.collideWorldBounds = true;
			plat.body.immovable = true;

			plat2 = game.add.sprite(2273,550,"plat2");
			plat2.scale.x=1;
			plat2.scale.y=1;
			game.physics.arcade.enable(plat2);
			plat2.body.collideWorldBounds = true;
			plat2.body.immovable = true;
			
			player = game.add.sprite(32,game.world.height -150,'dude');
			
			
			game.physics.arcade.enable(player);
			game.physics.arcade.enable(platforms);
			
			player.body.bounce.y = 0.9;
			player.body.gravity.y = 800;
			player.body.collideWorldBounds = true;
			
			player.animations.add('left',[0,1,2,3],10,true);
			player.animations.add('right',[5,6,7,8],10,true);
			player.body.velocity.x =0;
			

			timer=game.time.events.loop(Phaser.Timer.SECOND * 1,proseso.platMoveRight);
			timer=game.time.events.loop(Phaser.Timer.SECOND * 2,proseso.platMoveLeft);
			
			timer=game.time.events.loop(Phaser.Timer.SECOND * 2,proseso.plat2MoveDown);
			timer=game.time.events.loop(Phaser.Timer.SECOND * 1,proseso.plat2MoveUp);

			keyboard = game.input.keyboard.createCursorKeys();
			
			bestScoreText = game.add.text(570,20,"BestScore: "+ proseso.getScore(),{fill:'blue'});
			scoreText = game.add.text(50,20,"SCORE: 0",{fill:'blue'});
			
			stateText = game.add.text(game.world.centerX,game.world.centerY,' ', { font: '30px Arial', fill: 'black' });
		    stateText.anchor.setTo(0.5, 0.5);
			game.scale.refresh();




			
			game.camera.follow(player,Phaser.Camera.FOLLOW_TOPDOWN);
			scoreText.fixedToCamera = true;
			bestScoreText.fixedToCamera = true;
			scoreText.fixedToCamera = true;
			bestScoreText.fixedToCamera = true;
			button.fixedToCamera = true;
			button1.fixedToCamera = true;
			button2.fixedToCamera = true;
			btn.fixedToCamera = true;

			
			
			//titlepage = game.add.sprite(0,0, "title");
			//startButton = game.add.button(game.world.centerX -450, 330, 'btn', proseso.actionOnClick, this, 2, 1, 1);

	},

	update:function() {
			game.physics.arcade.collide(player,platforms,0,0);
			game.physics.arcade.collide(player,plat,0,0);
			game.physics.arcade.collide(player,plat2,0,0);
			game.physics.arcade.overlap(player,pins,proseso.killPlayer);
			game.physics.arcade.overlap(player,flag,proseso.killPlayerr);
			game.physics.arcade.overlap(player,plats,proseso.killcoin);
			
			var x= 0;
		    if(keyboard.left.isDown){
		         x++;
		        player.animations.play('left');
		        player.body.velocity.x = -200;
		        // bg.frame = 0;
		    }
		    else if(keyboard.right.isDown){
		         x++;
		        // bg.frame = 1;
		        player.animations.play('right');
		        player.body.velocity.x = 200;
		    }
		    else{
		        player.body.velocity.x = 0;
		        player.animations.stop();
		    }

		    if(keyboard.up.isDown && player.body.touching.down){
		        player.body.velocity.y = -500;
		    }
				
		}
}
game.state.add("Game",mambobola,true);