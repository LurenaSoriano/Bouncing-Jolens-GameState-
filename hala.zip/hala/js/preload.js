preloadGame = {
	preload :function() {

			game.load.image('ground','img/horin.png');
			game.load.image('grounded','img/vertical.png');
			game.load.image('grounds','img/plat.png');
			game.load.image('groundss','img/11.png');
			game.load.image('groundsse','img/plat1.png');
			game.load.image('groundse','img/plat2.png');
			game.load.image('groundee','img/plat3.png');
			game.load.image('groun','img/1.png');
			game.load.image('grou','img/hh.png');
			game.load.image('gro','img/ee.png');
			//game.load.image('btn1', 'img/start.png');
			
		   	game.load.image('title','img/harap.png',800,600);
			game.load.image('start', 'img/start.png');
			game.load.image('tiu','img/tgameover.png');
			game.load.spritesheet("restart","img/tigil.png");
			
			game.load.spritesheet("pause","img/tigil.png",100,100);
			
			game.load.spritesheet("button","img/btn-jump.png",100,100);
			game.load.spritesheet("button1","img/btn-left.png",100,100);
			game.load.spritesheet("button2","img/btn-right.png",100,100);
			game.load.image('tusok','img/pin.png');
			game.load.image('vtusok','img/pin2.png');
			game.load.image('bg','img/bg.png');
			game.load.spritesheet('dude','img/b.png',32,48);
			game.load.image('plat', 'img/moveplat.png');
			game.load.image('plat2','img/2.png');
			game.load.image('coin','img/r.png');
			game.load.image('coins','img/r2.png');
			game.load.image('coinss','img/flag.png');

			game.load.audio("bgmusic","audio/suspense.mp3");
			
	},
	create:function(){
			game.state.start('menuGame');
	},
}