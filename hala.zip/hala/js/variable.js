

var w = 800,h = 600;
var platforms,platformers,player,keyboard,score,score = 0, bestScore,getScore,Fires,coins,gameOverText,scoreText,fire, lifeText, life = 3,bestScoreText,shineDiamond,shineDiamonds,explodeFire,btn, timeText,tusok,plat;
var boundsRight = 4000;
var duration=30;
var titlepage;
var startButton;
var saveScore;
var actionOnClick;
var restart;
var talon,kanan,kaliwa,tigilTuloy;
var platMoveRight,platMoveLeft,plat2MoveDown,plat2MoveUp;
var game = new Phaser.Game(800, 600, Phaser.CANVAS, '');

game.state.add('bootGame', bootGame);
game.state.add('preloadGame', preloadGame);
game.state.add('menuGame', menuGame);
game.state.add('playGame', playGame);
game.state.add('winGame', winGame);
//game.state.add('helpGame', helpGame);
//game.state.add('aboutGame', aboutGame);

game.state.start('bootGame');