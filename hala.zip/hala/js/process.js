var proseso = function(){
    "use strict";
    return {
      /*  actionOnClick:function(){
        	titlepage.visible =! startButton.visible;
        	startButton.destroy();
        	button.frame = 1;

        },*/

        killcoin:function(player,coin){
            score = score + 1;
            scoreText.text = "SCORE:"+ score;
            coin.kill();
            
        	
            if(proseso.getScore()<=score){
                proseso.saveScore(score);
                bestScoreText.text = "bestscore: "+score;
            }
        },

        talon:function(){
            button.frame = 1;
            if(player.body.touching.down){

                player.body.velocity.y = -500;
            }

            setTimeout(function(){
                button.frame = 0;
            },300)
        },


        kanan:function(){
           button1.frame = 1;
            //	if(keyboard.left.isDown){
           		player.body.velocity.x = -2500;
           		player.animations.add('left',[0,1,2,3,4],10,true);
           	//	}
            setTimeout(function(){
            	
            	player.animations.play('left');

                button1.frame = 0;
               },300)
        },


        kaliwa:function(){
            button2.frame = 1;
            //	if(keyboard.right.isDown){
            	player.animations.add('right',[5,6,7,8],10,true);
           		player.body.velocity.x = 2500;
           	//	}
            setTimeout(function(){
        		player.animations.play('right');

                button2.frame = 0;
               },100)
        },
        tigilTuloy:function(){
            setTimeout(function(){
                btn.frame = 1;
                game._paused = false;

            },3000)
            	btn.frame = 0;

            game._paused =true;
        },  	




        getScore:function(){
            return (localStorage.getItem("gameData") == null || localStorage.getItem("gameData") == "")?0:localStorage.getItem("gameData");
        },
        saveScore:function(score){
            localStorage.setItem("gameData",score);
        },

        platMoveRight:function() {
            
        			plat.body.velocity.x = 250;
                    plat.animations.play('right');

        },
        platMoveLeft:function() {
            
        			plat.body.velocity.x = -250;
                    plat.animations.play('left');

        },

        plat2MoveDown:function() {
            
        		plat2.body.velocity.y = -300;
        		plat2.animations.play('down');

        },
        plat2MoveUp  :function() {
            
        		plat2.body.velocity.y =300;
        		plat2.animations.play('up');

        },


        killPlayer:function(player,tusok){
               gameOverText = game.add.text(w/2-100,h/2,"GAME OVER!! \n DOUBLE TAP \n    to restart ",{fill:'red'});
               gameOverText.fixedToCamera = true;
        	   player.animations.stop();
                bgmusic.stop();
        	  // stateText.text="DOUBLE TAP \n    to restart";
               game._paused = true; 
               
                player.kill();
                game.input.onTap.addOnce(proseso.restart,this) 
        	   game._paused=true;
        	 //  player.kill();
        	   

        },

        restart :function(){
            window.location.href=window.location.href;
            stateText.visible = false;
        },

        killPlayerr:function(player,flag){
               gameOverText = game.add.text(w/2-100,h/2,"YOU WIN !!",{fill:'BLUE'});
               gameOverText.fixedToCamera = true;
            bgmusic.stop();
        	   player.animations.stop();
        	   stateText.text="DOUBLE TAP \n    to restart";   
            	game._paused = true; 
               
                player.kill();
                game.input.onTap.addOnce(proseso.restart,this)  

        	   game._paused=true;
        	 //  player.kill();
        	   

        }
  }
}();